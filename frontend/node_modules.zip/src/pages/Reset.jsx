import React from 'react'

const Reset = () => {
  return (
    <div>
      reset pass page
    </div>
  )
}

export default Reset
