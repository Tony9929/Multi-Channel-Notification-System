import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'

const Login = () => {
  const navigate= useNavigate()
  const [state, setstate] = useState('Sign Up')
  return (
    <div className='flex justify-center items-center min-h-screen px-6 sm:px-0 bg-gradient-to-br from-blue-200 to-purple-400'>
      <div className='border-2 bg-gray-800 px-12 py-14  rounded-md'>
        <h2 className='text-center font-semibold text-white'>{state === 'Sign Up' ? 'Create Account ' : 'Login'}</h2>
        <p className='text-center text-white'>{state === 'Sign Up' ? 'Create an Account ' : 'Login in an Account'}</p>

        <form className='flex flex-col ' action="" >
          { state==="Sign Up" && (<input className='bg-gray-600 mt-1 rounded-2xl pl-1 py-0.5' type="text" placeholder='Full name' required />)} 

          <input className='bg-gray-600 mt-1 rounded-2xl pl-1 py-0.5' type="email" placeholder='email id' required />
          <input className='bg-gray-600 mt-1 rounded-2xl pl-1 py-0.5' type="password" placeholder='password' required />
          <p onClick={()=>navigate('/Reset')} className='text-sm text-blue-600 cursor-pointer'>Forgot password?</p>

          <button className='w-full py-2.5 rounded-full bg-blue-300'>{state}</button>

          <p className='mt-2 text-center '>{state === 'Sign Up' ? ' Already have a account? ' : 'create a account'}</p>
          <span onClick={() => {
            setstate(state === 'Sign Up' ? 'Login here' : 'Sign Up');
          }}  className='text-sm text-blue-600  cursor-pointer'>{state === 'Sign Up' ? ' Login' : 'Sign up'}</span>

        </form>
      </div>

    </div>
  )
}

export default Login
