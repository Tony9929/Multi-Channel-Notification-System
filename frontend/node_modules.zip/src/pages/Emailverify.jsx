import React from 'react'

const Emailverify = () => {
  return (
    <div>
      verify page
    </div>
  )
}

export default Emailverify
