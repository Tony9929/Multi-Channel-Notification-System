import React from 'react'
import { Route,Routes } from 'react-router-dom'
import Home from './pages/home'
import Login from './pages/login'
import Reset from './pages/reset'
import Emailverify from './pages/emailverify' 

const App = () => {
  return (
    <div>
      
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/login' element={<Login/>} />
        <Route path='/reset' element={<Reset/>} />
        <Route path='/emailverify' element={<Emailverify/>} />
      </Routes>
    </div>
  )
}

export default App
